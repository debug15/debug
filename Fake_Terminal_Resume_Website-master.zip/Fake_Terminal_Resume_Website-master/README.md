# Fake Terminal Resume Website

## PLEASE FORK INSTEAD OF CLONING

## If you like this project please give it a star

Are you addicted to terminals?

Does a hacker ignite whenever you see one??

Do you want terminals everywhere???

Then this website template is for you.

A Fake terminal website for coders.

Live Demo [here](https://rimijoker.github.io/Fake_Terminal_Resume_Website/)
![Live website image](Screenshot.png)
